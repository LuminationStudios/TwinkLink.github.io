export const DUMMY_PROFILES = [
  { id: 'u1', displayName: 'Alex', age: 24, city: 'Brooklyn', bio: 'Designer & coffee fan', photoURL: '' },
  { id: 'u2', displayName: 'Noah', age: 26, city: 'Manhattan', bio: 'Loves hiking and cats', photoURL: '' },
  { id: 'u3', displayName: 'Evan', age: 22, city: 'Queens', bio: 'Student, gamer, cook', photoURL: '' },
  { id: 'u4', displayName: 'Riley', age: 27, city: 'Brooklyn', bio: 'Photographer', photoURL: '' }
]
